       /////    /////    /////////////
      CCCCC/   CCCCC/   | CC-attack |/
     CC/      CC/       |-----------|/ 
     CC/      CC/       |  Layer 7  |/ 
      CC/////  CC/////  | ddos tool |/ 
       CCCCC/   CCCCC/  |___________|/

# CC-attack ![](https://img.shields.io/badge/Version-3.6-brightgreen.svg) ![](https://img.shields.io/badge/license-GPLv2-blue.svg)
  Một tập lệnh sử dụng các proxy 4/5 để tấn công các máy chủ http.

Tin tức:
- [x] Đã thêm chỉ báo đầu ra
- [x] Đã thêm trình phân tích cú pháp Url

  Thông tin:
- [x] Sử dụng Python3
- [x] Đã thêm nhiều tùy chọn giống người hơn
- [x] Http Get / Head / Post / Slow Flood
- [x] Tiêu đề / Dữ liệu Http Ngẫu nhiên
- [x] Socks4 / 5 Proxies Downloader
- [x] Socks4 / 5 Proxy Checker
- [x] Tùy chỉnh Cookie
- [x] Tùy chỉnh dữ liệu bài đăng
- [x] Hỗ trợ HTTPS
- [x] Vớ hỗ trợ4 / 5

## Minh họa

![](https://i.imgur.com/hXGBnkB.png)

## Cài đặt

    pip3 install requests pysocks
    git clone https://github.com/DauDau432/CC-attack
    cd CC-attack

## Cách sử dụng

    python3 cc.py
